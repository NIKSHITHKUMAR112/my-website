$(document).ready(function(){
    $("h1").css("color", "blue");
});